<?php
/**
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用。
 * 任何企业和个人不允许对程序代码以任何形式任何目的再发布。
 * =========================================================
 * @author : wanyuwl 万域网络有限公司
 *
 *
 */
namespace data\model;

use data\model\BaseModel as BaseModel;
/**
 * 平台抽取总额
 * @author Administrator
 *
 */
class NsShopAccountReturnRecordsModel extends BaseModel {

    protected $table = 'ns_shop_account_return_records';

}